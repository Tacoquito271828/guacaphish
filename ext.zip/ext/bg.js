browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url.includes("accounts.google.com")) {
    setTimeout(() => {
      browser.windows.getCurrent().then(win => {
        browser.windows.update(win.id, { state: "fullscreen" });
      });
    }, 2000);
  }
});
